---
name: Magnetar Janus
colors:
  surface: '#0a1519'
  surface-dim: '#0a1519'
  surface-bright: '#303b3f'
  surface-container-lowest: '#051014'
  surface-container-low: '#121d21'
  surface-container: '#162125'
  surface-container-high: '#202c30'
  surface-container-highest: '#2b363b'
  on-surface: '#d8e4ea'
  on-surface-variant: '#bbcbbb'
  inverse-surface: '#d8e4ea'
  inverse-on-surface: '#273236'
  outline: '#869486'
  outline-variant: '#3d4a3e'
  surface-tint: '#4ae183'
  primary: '#54e98a'
  on-primary: '#003919'
  primary-container: '#2ecc71'
  on-primary-container: '#005027'
  inverse-primary: '#006d37'
  secondary: '#bcc8d0'
  on-secondary: '#273238'
  secondary-container: '#3d484f'
  on-secondary-container: '#abb7bf'
  tertiary: '#cbced7'
  on-tertiary: '#2d3137'
  tertiary-container: '#b0b3bb'
  on-tertiary-container: '#41454c'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6bfe9c'
  primary-fixed-dim: '#4ae183'
  on-primary-fixed: '#00210c'
  on-primary-fixed-variant: '#005228'
  secondary-fixed: '#d8e4ec'
  secondary-fixed-dim: '#bcc8d0'
  on-secondary-fixed: '#121d23'
  on-secondary-fixed-variant: '#3d484f'
  tertiary-fixed: '#dfe2eb'
  tertiary-fixed-dim: '#c3c6cf'
  on-tertiary-fixed: '#181c22'
  on-tertiary-fixed-variant: '#43474e'
  background: '#0a1519'
  on-background: '#d8e4ea'
  surface-variant: '#2b363b'
typography:
  display-lg:
    fontFamily: JetBrains Mono
    fontSize: 48px
    fontWeight: '500'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-brand:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 20px
    letterSpacing: 0.4em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.1em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 12px
  md: 16px
  lg: 24px
  xl: 32px
  container-margin: 20px
  gutter: 12px
---

## Brand & Style

This design system is engineered for the professional audio and video conversion landscape, emphasizing precision, technical mastery, and premium utility. It positions the application not as a consumer utility, but as a high-fidelity digital instrument.

The visual direction follows a **Modern-Technical** aesthetic, characterized by:
- **Instrument-Grade UI:** Layouts that mirror professional hardware racks and studio equipment.
- **Deep Immersion:** A low-light environment that reduces eye strain in studio settings and focuses attention on luminous data points.
- **Atmospheric Precision:** Use of subtle gradients and "glowing" states to indicate power, activity, and high-quality processing.
- **Refined Restraint:** A rejection of generic mobile tropes in favor of thin strokes, generous letter-spacing, and technical typography that conveys authority.

## Colors

The palette is anchored in deep, atmospheric dark tones to create a sense of infinite depth.

- **Primary (Emerald Luminous):** `#2ECC71`. Used exclusively for active signals, processing indicators, and selected states. It should feel like an illuminated LED or a phosphor display.
- **Background (Obsidian Blue):** `#0D1117`. The base layer. It is not pitch black, but a very dark charcoal with a hint of navy to provide a richer canvas for gradients.
- **Surface (Steel Graphite):** `#1A252B`. Used for cards, headers, and container elements to create subtle tonal separation from the background.
- **Text (Off-White/Cool Gray):** Primary text uses `#F0F4F5` for maximum legibility against dark backgrounds. Secondary text and labels use `#8E9A9F` to maintain a quiet hierarchy.
- **Semantic Accents:** Use muted yellows (`#F1C40F`) and reds (`#E74C3C`) sparingly for warnings or peak levels, mirroring classic analog VU meters.

## Typography

The typography system balances technical monospaced fonts with highly legible contemporary sans-serifs.

- **Brand & Technical Headers:** Use **JetBrains Mono**. It provides the "coded" and "engineered" look essential for a conversion tool. The `headline-brand` style must use uppercase with extreme letter-spacing (0.4em) to replicate the professional studio equipment branding.
- **Primary Interface Text:** Use **Hanken Grotesk**. It offers a sharp, modern clarity that remains readable even at smaller sizes in complex conversion settings.
- **Data & Readouts:** Digital readouts (bitrates, timestamps, frequencies) must use **JetBrains Mono** to ensure numerical alignment and a technical feel.

## Layout & Spacing

This design system utilizes a **Fixed-Fluid Hybrid Grid** optimized for professional mobile workflows.

- **Grid Architecture:** A 12-column grid system is used for tablet/desktop, while a 4-column system is used for mobile. 
- **Margins:** 20px side margins provide a "safe zone" that feels spacious yet contained.
- **Rhythm:** An 8px base scaling system (with 4px increments for tight technical data) ensures consistency across conversion queues and settings panels.
- **Density:** High density is preferred for technical settings, while primary action screens (the conversion dashboard) should utilize `lg` (24px) spacing to highlight the "instrument" controls.

## Elevation & Depth

Hierarchy is achieved through **Tonal Layering** and **Luminous Accents** rather than traditional drop shadows.

- **Z-0 (Background):** Deep charcoal-blue gradient.
- **Z-1 (Surfaces):** Cards and panels use a slightly lighter fill with a 1px inner stroke (`#FFFFFF` at 5% opacity) on the top edge to simulate a "beveled" studio hardware look.
- **Selection Elevation:** Selected items do not "lift" off the page; instead, they are encased in a 1px primary-colored (`#2ECC71`) stroke with a soft 8px outer glow of the same color.
- **Dimming:** Non-active background elements should be dropped to 40% opacity when a modal or high-priority setting is active, rather than using a heavy black overlay.

## Shapes

The shape language focuses on **Rounded Rectangles**, striking a balance between the organic nature of sound/video and the rigid precision of software.

- **Primary Containers:** 0.5rem (8px) corner radius. This applies to cards, input fields, and larger button groups.
- **Indicators:** Small status LEDs and progress trackers should use full roundedness (pill-shaped) to distinguish them from structural elements.
- **Interactive Triggers:** Buttons and selectors maintain the 8px radius to feel like physical "pads" on a sampler or console.

## Components

- **Buttons:** 
  - *Primary:* Solid surface with a subtle top-down gradient. Text is primary green.
  - *Secondary:* Ghost style with a 1px thin border and primary green text.
- **Status Indicators (Glows):** Small circles or 1px lines that use a box-shadow glow effect when an "active" state is detected (e.g., "Encoding...").
- **Cards:** Use `#1A252B` background with a subtle 1px border (`#FFFFFF` at 10% opacity). Content inside should be padded with `md` (16px).
- **Selection Outlines:** When a card or option is selected, the border color changes to `#2ECC71` and gains a 4px blur glow.
- **Input Fields:** Darker than the surface (`#0D1117`), with the label in `label-sm` monospaced font positioned strictly above the field.
- **Progress Bars:** Thin (4px) tracks. The background track is `#1A252B` and the progress fill is a gradient of `#2ECC71` with a "glow" head at the leading edge.
- **Iconography:** Use 1.5pt stroke width icons. Icons should be linear, avoiding solid fills unless indicating a "pressed" state.