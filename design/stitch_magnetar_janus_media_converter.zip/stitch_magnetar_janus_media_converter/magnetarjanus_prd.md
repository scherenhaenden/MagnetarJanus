# MagnetarJanus Product Requirements

## Overview
A professional Android audio/video conversion and splitting application. Visual sibling to MagnetarOrpheus.

## Visual Identity
- **Brand**: MAGNETAR (wide letter-spaced) with a thin green accent. JANUS in green uppercase underneath.
- **Palette**: Deep charcoal/blue-black, emerald green accents, cool gray secondary text, white primary text.
- **Style**: Studio equipment, technical, precise.

## Core Screens & Features

### 1. Main Screen / Import Area
- Large dark rounded panel with video/audio icon.
- State 1 (Empty): "Select media" CTA.
- State 2 (Populated - Video): Thumbnail, filename, duration, resolution, fps, codec, size.
- State 3 (Populated - Audio): Horizontal emerald waveform (Orpheus style).

### 2. Operation Selector (Horizontal)
- Options: CONVERT — SPLIT — AUDIO.
- Style: Matches Orpheus note selector (green illuminated outline, subtle glow).

### 3. Convert Mode
- Source -> Destination visual mapping.
- Format chips: MP4, WebM, MKV (Video); MP3, AAC, WAV, FLAC (Audio).
- Advanced toggles for bitrate/resolution.

### 4. Split Mode (Centerpiece)
- Timeline with thumbnails (video) or waveform (audio).
- Luminous green playhead.
- **WhatsApp Split Section**: Preset buttons (30s, 60s, 90s) + Custom.
- Preview logic: Shows segment breakdown (e.g., "5 segments · 01:00...").
- Manual splitting: "Split here" control creating thin vertical luminous lines.

### 5. Audio Mode
- Video source: "Extract Audio" action.
- Audio source: Specific conversion/splitting tools with waveform.

### 6. Output & Action
- Configuration cards: "OUTPUT FORMAT", "QUALITY".
- Primary Action Button: "Convert", "Split", or "Export" (Contextual).
- Progress state: Green accent becomes a progress bar with percentage and estimated size.